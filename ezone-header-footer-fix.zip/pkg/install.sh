#!/usr/bin/env bash
# Run from E:/E-ZONE/frontend :  bash /path/to/ezone-fix/install.sh
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"

if [ ! -f package.json ] || [ ! -d src ]; then
  echo "❌ Run this from the frontend folder (/e/E-ZONE/frontend)"; exit 1
fi

HDR=$(find src -name Header.jsx | head -n1)
FTR=$(find src -name Footer.jsx | head -n1)
if [ -z "$HDR" ] || [ -z "$FTR" ]; then
  echo "❌ Header.jsx or Footer.jsx not found under src/"; exit 1
fi
HDIR=$(dirname "$HDR"); FDIR=$(dirname "$FTR")

cp "$HERE/files/HeaderFix.css" "$HDIR/HeaderFix.css"
cp "$HERE/files/Footer3D.css"  "$FDIR/Footer3D.css"
cp "$HERE/files/Footer.jsx"    "$FTR"

if ! grep -q "HeaderFix.css" "$HDR"; then
  sed -i "s#import './Header.css';#import './Header.css';\nimport './HeaderFix.css';#" "$HDR"
fi

echo "✅ Installed:"
echo "   $HDIR/HeaderFix.css"
echo "   $FDIR/Footer3D.css"
echo "   $FTR (replaced)"
grep -n "HeaderFix" "$HDR" || { echo "⚠️  import not added to Header.jsx — add: import './HeaderFix.css';"; }
